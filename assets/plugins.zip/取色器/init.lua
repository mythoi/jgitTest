appname="取色器"
appver="1.3"
packagename="com.androlua.color"
theme="Theme"
developer="烧"
mode="plugin"
description="取颜色代码,点击颜色代码复制到剪贴板。"
debugmode=true
user_permission={
  
}
